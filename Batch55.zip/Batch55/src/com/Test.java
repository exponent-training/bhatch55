package com;

public class Test {

//	resource allocation -> DB connection.

	static {
		System.out.println("s-1");
	}
	
	

	{
		System.out.println("NS-1");
	}

	public static void main(String[] args) {

		Test t = new Test();
		Test t1 = new Test();
		Test t2 = new Test();

	}

	// 1.7->
}
