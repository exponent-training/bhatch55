package com.SuperAndThis;

public class Example1 {

	int x = 100;

	int y = 500;

	public void m1() {
		System.out.println("M1 Method from Parent");
	}
}
