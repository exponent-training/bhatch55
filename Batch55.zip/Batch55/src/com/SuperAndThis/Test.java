package com.SuperAndThis;

public class Test extends ConstrucotrChaining {

	Test() {
		System.out.println("Child Cons");
	}

	Test(int i) {
		this(102, true);
		System.out.println("Interge Cons Child");
	}

	Test(int i, boolean flag) {

		System.out.println("2 parameter child cons.");
	}

	public static void main(String[] args) {

		Test t = new Test();
		Test t1 = new Test();

	}

}
