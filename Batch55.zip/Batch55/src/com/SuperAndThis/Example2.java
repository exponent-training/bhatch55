package com.SuperAndThis;

public class Example2 extends Example1 {

//	child+parent => M1;

	int y = 1000;

	int x = 1;

	public void m1() {
		System.out.println("M1 Method from Child");
	}

	public void m2() {
		System.out.println("M2 Method From Child");
	}

	public void Details() {
		System.out.println(super.x);
		this.m1();
	}

	public void SameDetails() {
		System.out.println(this.y);
		this.m2();
	}

	public static void main(String[] args) {

		Example2 ex = new Example2();
		ex.Details();

//		ex.SameDetails();

	}

}
