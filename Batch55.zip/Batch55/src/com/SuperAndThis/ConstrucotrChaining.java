package com.SuperAndThis;

public class ConstrucotrChaining {

	ConstrucotrChaining() {
		this(452.5f);
		System.out.println("Parent cons");
	}

	ConstrucotrChaining(float f) {
		System.out.println("1 param-Parent cons ");
	}

}
