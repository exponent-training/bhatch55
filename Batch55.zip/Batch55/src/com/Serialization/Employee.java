package com.Serialization;

import java.io.Serializable;

public class Employee implements Serializable {

	private int eid;

	private transient String ename;

	private transient String eaddress;

	private int eacno;

	private String epassword;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname(pa) {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEaddress() {
		return eaddress;
	}

	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}

	public int getEacno() {
		return eacno;
	}

	public void setEacno(int eacno) {
		this.eacno = eacno;
	}

	public String getEpassword() {
		return epassword;
	}

	public void setEpassword(String epassword) {
		this.epassword = epassword;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eaddress=" + eaddress + ", eacno=" + eacno
				+ ", epassword=" + epassword + "]";
	}

}
