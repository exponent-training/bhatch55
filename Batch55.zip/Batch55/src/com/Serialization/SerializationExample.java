package com.Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationExample {

	public static void main(String[] args) throws IOException {

		Employee emp = new Employee();
		emp.setEacno(12453);
		emp.setEid(101);
		emp.setEaddress("Pune");
		emp.setEpassword("XYZ");
		emp.setEname("Raj");

//		System.out.println(emp);

		FileOutputStream file = new FileOutputStream("employeeDetails.txt");
		ObjectOutputStream obj = new ObjectOutputStream(file);
		obj.writeObject(emp);
		System.out.println("object Serialized");

	}
}
