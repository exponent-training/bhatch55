package com;

public class Test1 {

	static int no = 10;

	String name = "ram";
	String collegName = "xyz";

	public static void m1() {

		System.out.println(name);
		System.out.println(collegName);
		nsmethod();
	}

	public void nsmethod() {
		System.out.println(name);
		System.out.println();
		System.out.println(Test1.no);
		System.out.println(no);
		m1();
	}

	public static void main(String[] args) {

		System.out.println(Test1.no);
		System.out.println(no);
		m1();
	}

	public static void m2() {
		System.out.println(Test1.no);
		System.out.println(no);
		m1();
	}

}
