package com;

public class Student {

	int sid;

	String sname;

	public static void m1() {
//		600 line
		// 50
	}

	// class meomary
	static String collegeName = "PCCOE";

	public static void main(String[] args) {

		// 50
		// heap meomary -> s1(sid,sname,collegeName) , s2((sid,sname,collegeName)
		Student s1 = new Student();
		s1.sid = 101;
		s1.sname = "raj";
		System.out.println(s1.sid);
		System.out.println(s1.sname);
		System.out.println(Student.collegeName);

		Student s2 = new Student();
		s2.sid = 102;
		s2.sname = "ram";
		System.out.println(s2.sid);
		System.out.println(s2.sname);
		System.out.println(Student.collegeName);

		Student.m1();

	}

}
