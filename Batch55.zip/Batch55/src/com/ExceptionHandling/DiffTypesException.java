package com.ExceptionHandling;

import java.io.FileInputStream;

public class DiffTypesException {

	public static void main(String[] args) {

//		String str = null;
//		System.out.println(str.toLowerCase());
		
//		int n = 10/0;
//		System.out.println(n);
		
//		FileInputStream file = new FileInputStream("dummy");
		
		
//		Class.forName("A.class");
		

	}

}
