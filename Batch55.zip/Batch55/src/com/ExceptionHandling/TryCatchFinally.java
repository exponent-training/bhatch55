package com.ExceptionHandling;

public class TryCatchFinally {

	public static void main(String[] args) {

//		Database connection.
//		db.open();

		try {

//			String str = null;
//			System.out.println(str.toLowerCase());

			System.out.println("Line-1");
			System.out.println("Line-2");

//			db.close();

		} catch (Exception e) {

			System.out.println("Exception handled here");

		} finally {

//			db.Close
			System.out.println("DB connection closed");
		}

//		

	}

}
