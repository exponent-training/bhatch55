package com.ExceptionHandling;

public class MultipleExceptionExample {

	public static void main(String[] args) {

		String str[] = { null, "abc", "xyz", null, null };

		for (int i = 0; i < str.length + 1; i++) {

			try {
				String string = str[i].toLowerCase() + Integer.parseInt(str[i]);
			} catch (NullPointerException e) {

				System.out.println("Array has null value at " + i);
			} catch (NumberFormatException e) {
				System.out.println("NumberFormatException occures here");
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("size exceed");
			}
		}

	}
}
