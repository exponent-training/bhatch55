package com.ExceptionHandling;

public class TryWithMultipleCatch {

	public static void main(String[] args) {

		try {

//			String str = null;
//			System.out.println(str.toCharArray());

			int n = 10 / 0;// Arithmatic

		} catch (NullPointerException e) {

			System.out.println("Nullpointer handles here - dont use null values");
		} catch (Exception e) {

			System.out.println("Exception handles here - wrong arithmatic operation");
		} catch (Throwable e) {

			System.out.println("Throwable handles here - wrong arithmatic operation");
		}

	}
}
