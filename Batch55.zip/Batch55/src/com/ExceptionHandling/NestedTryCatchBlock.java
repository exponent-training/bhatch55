package com.ExceptionHandling;

public class NestedTryCatchBlock {

	public static void main(String[] args) {

		try {

			try {

				try {

					String str = "name";

					System.out.println(str.charAt(20));

				} catch (ArrayIndexOutOfBoundsException e) {
					System.out.println("ArrayIndexOutOfBoundsException ");
				}

			} catch (ArithmeticException e) {

				System.out.println("ArithmeticException");
			}

		} catch (Exception e) {

			System.out.println("outer catch block Exception");
		}

	}
}
