package com.ExceptionHandling;

public class ExceptionExample {

	public static void main(String[] args) {

		System.out.println("line-1");
		System.out.println("line-2");
		System.out.println("line-3");
		System.out.println("line-4");

		try {
			int n = 10 / 0;
		} catch (Exception e) {

			System.out.println(e);
			System.out.println("Exception handled");
		}

		System.out.println("line-7");
		System.out.println("line-8");

	}

}
