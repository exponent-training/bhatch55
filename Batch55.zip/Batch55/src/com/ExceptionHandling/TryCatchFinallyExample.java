package com.ExceptionHandling;

public class TryCatchFinallyExample {

	public int result() {
		try {

			System.out.println("Hello");
			System.out.println("Hi");
			System.out.println("Bye");
			
//			System.exit(0);
			
			return 100;
			
			

		} catch (Exception e) {
			return 1000;

		} finally {

			System.out.println("hello");
			
//			System.out.println("world");

			return 1;
		}

	}

	public static void main(String[] args) {

		TryCatchFinallyExample t = new TryCatchFinallyExample();
		int result = t.result();
		System.out.println(result);

	}
}
