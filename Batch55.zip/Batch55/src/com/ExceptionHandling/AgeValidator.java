package com.ExceptionHandling;

public class AgeValidator extends RuntimeException {

	AgeValidator(String msg) {
		super(msg);
	}

}
