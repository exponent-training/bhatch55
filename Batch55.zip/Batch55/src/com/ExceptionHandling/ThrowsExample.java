package com.ExceptionHandling;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ThrowsExample {

	public static void m1() throws FileNotFoundException {

//		String str = null;
//		System.out.println(str.toLowerCase());

		FileOutputStream file = new FileOutputStream("test.txt");
		

	}

	public static void main(String[] args) {

		try {
			m1();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static void m3() {
		try {
			m1();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
