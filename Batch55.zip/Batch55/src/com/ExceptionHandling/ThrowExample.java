package com.ExceptionHandling;

public class ThrowExample {

//	Throw -> propogation of Exception.

	public static void main(String[] args) {

		int age = 15;

		if (age >= 18) {
			System.out.println("Eligible for Voating");
		} else {
			throw new AgeValidator("Not eligible for voating");
		}

	}

}
