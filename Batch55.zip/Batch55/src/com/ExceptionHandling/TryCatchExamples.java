package com.ExceptionHandling;

public class TryCatchExamples {
	
	static {
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	{
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	TryCatchExamples()
	{
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	public void m1()
	{
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String[] args) {
		
		try {
			
			
			try {
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			
			
			
		} catch (Exception e) {
			
			
			try {
				
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			
		}
	}
	
}
